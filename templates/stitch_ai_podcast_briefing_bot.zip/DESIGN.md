---
name: Crimson Noir
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#e9bcb6'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#af8782'
  outline-variant: '#5e3f3b'
  surface-tint: '#ffb4aa'
  primary: '#ffb4aa'
  on-primary: '#690003'
  primary-container: '#e50914'
  on-primary-container: '#fff7f6'
  inverse-primary: '#c0000c'
  secondary: '#c6c6c7'
  on-secondary: '#2f3131'
  secondary-container: '#454747'
  on-secondary-container: '#b4b5b5'
  tertiary: '#c8c6c5'
  on-tertiary: '#313030'
  tertiary-container: '#737272'
  on-tertiary-container: '#fbf8f7'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad5'
  primary-fixed-dim: '#ffb4aa'
  on-primary-fixed: '#410001'
  on-primary-fixed-variant: '#930007'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#e5e2e1'
  tertiary-fixed-dim: '#c8c6c5'
  on-tertiary-fixed: '#1c1b1b'
  on-tertiary-fixed-variant: '#474746'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
  max-width: 1200px
---

## Brand & Style

The design system is engineered for **PodcastBriefBot**, a premium service providing high-signal summaries for busy professionals. The brand personality is authoritative, sophisticated, and focused, catering to an audience that values time and intellectual depth.

The design style is **High-Contrast Editorial**. It leverages a deep Obsidian backdrop to make content "pop," utilizing a "Crimson & Alabaster" palette to guide the eye through dense information. The aesthetic leans into a cinematic, news-magazine feel, combining the raw impact of dark-mode minimalism with the refined elegance of traditional publishing. Visual interest is generated through extreme typographic scale and intentional whitespace rather than decorative elements.

## Colors

The color palette is strictly curated to maintain a high-contrast, premium environment. 

- **Primary (Crimson):** Used exclusively for high-priority actions, accents, and the "Brief" portion of the brand identity.
- **Surface (Obsidian):** The base layer is a deep `#0A0A0A`. Elevated surfaces (cards, menus) use a slightly lighter `#1A1A1A` to create subtle depth without losing the dark aesthetic.
- **Content (Alabaster):** Pure `#FFFFFF` for primary text and icons to ensure maximum legibility against the dark background.
- **Subtext (Gray):** `#A0A0A0` is reserved for secondary metadata, labels, and less critical UI elements to maintain a clear visual hierarchy.

## Typography

This design system uses a high-contrast typographic pairing to evoke an editorial feel.

- **Headlines:** `Playfair Display` provides a sophisticated, authoritative voice. Use it for article titles, section headers, and the wordmark. Large display sizes should use tight letter spacing.
- **Body & UI:** `Inter` provides a functional, neutral counterpoint. It is used for the "Brief" summaries and all interactive UI elements. 
- **The Wordmark:** 'Podcast' (Playfair Display, 300 Weight, White), 'Brief' (Playfair Display, 700 Weight, Crimson), 'Bot' (Inter, 800 Weight, White).

## Layout & Spacing

The layout philosophy follows a **Fixed Grid** model for desktop and a **Fluid** model for mobile, emphasizing generous margins and vertical rhythm.

- **Desktop:** A 12-column grid centered in a 1200px container. Large "Editorial" gutters (24px) prevent content from feeling crowded.
- **Mobile:** A 4-column fluid grid with 20px side margins.
- **Spacing Rhythm:** All spacing is derived from a 4px base unit. Use larger gaps (48px+) between major sections to maintain the premium, "breathable" feel characteristic of high-end publications.

## Elevation & Depth

This design system avoids heavy shadows and skeuomorphism. Depth is communicated through **Tonal Layers** and **Low-Contrast Outlines**.

- **Surfaces:** Use `#1A1A1A` for cards or modals to distinguish them from the base `#0A0A0A` background.
- **Borders:** UI elements use thin, 1px borders in `#2A2A2A` (Low contrast) or `#E50914` (Active state).
- **Highlights:** No glows or blurs are used. Selection and focus are indicated by solid Crimson accents or Alabaster outlines.

## Shapes

The shape language is architectural and sharp. 

- **Corners:** A subtle `4px` (Soft) radius is used on all primary UI components (buttons, cards, inputs) to take the "edge" off while maintaining a precise, structured appearance.
- **Icons:** Use sharp, 1.5pt stroke icons to match the weight of the `Inter` typeface.

## Components

- **Buttons:** Primary buttons are solid Crimson (`#E50914`) with White bold text. Secondary buttons use a 1px White border with no fill.
- **Input Fields:** Deep black fill (`#000000`) with a 1px Gray (`#333333`) border. The border turns Crimson on focus.
- **Chips/Tags:** Small, rectangular, with a Crimson left-border (2px) and a dark gray background.
- **Cards:** Used for brief previews. No shadow; 1px subtle border. Titles must be in `Playfair Display`.
- **Progress Bars:** For audio playback or reading progress, use a Crimson foreground on a dark gray background.
- **Lists:** Clean dividers using 1px `#1A1A1A`. Hover states should subtly lighten the background to `#151515`.